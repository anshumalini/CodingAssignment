package com.lemonmarkets.Codingassignmentbackend.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.lemonmarkets.Codingassignmentbackend.exception.ErrorResponse;
import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.Order;
import com.lemonmarkets.Codingassignmentbackend.services.OrderService;
import com.lemonmarkets.Codingassignmentbackend.services.Validator;


public class OrderReceiverControllerTest {

	@InjectMocks
    private OrderReceiverController controller;
	
	@Mock
    private OrderService orderService;
	
	@Mock
    private Validator validator;

	@BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateOrderWithValidInput() {
        CreateOrderModel model = new CreateOrderModel();
        when(validator.isValidOrder(model)).thenReturn("");
        Order order = new Order();
        when(orderService.createOrder(model)).thenReturn(order);

        ResponseEntity<?> response = controller.createOrder(model);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(order, response.getBody());
    }

    @Test
    public void testCreateOrderWithInvalidInput() {
        CreateOrderModel model = new CreateOrderModel();
        String errorMessage = "Invalid order";
        when(validator.isValidOrder(model)).thenReturn(errorMessage);

        ErrorResponse expectedErrorResponse = new ErrorResponse(errorMessage);
        ResponseEntity<?> response = controller.createOrder(model);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        ErrorResponse exception = (ErrorResponse) response.getBody();
        assertEquals(expectedErrorResponse.getMessage(), exception.getMessage());
    }

    @Test
    public void testCreateOrderWithServerError() {
        CreateOrderModel model = new CreateOrderModel();
        when(validator.isValidOrder(model)).thenReturn("");
        when(orderService.createOrder(model)).thenReturn(null);

        ResponseEntity<?> response = controller.createOrder(model);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Internal server error while placing the order", response.getBody());
    }

    @Test
    public void testGetOrdersWithExistingOrders() {
        List<Order> orders = Collections.singletonList(new Order());
        when(orderService.getOrders()).thenReturn(orders);

        ResponseEntity<?> response = controller.getOrders();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(orders, response.getBody());
    }

    @Test
    public void testGetOrdersWithNoExistingOrders() {
        List<Order> orders = Collections.emptyList();
        when(orderService.getOrders()).thenReturn(orders);

        ResponseEntity<?> response = controller.getOrders();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("No order found in DB", response.getBody());
    }
}
