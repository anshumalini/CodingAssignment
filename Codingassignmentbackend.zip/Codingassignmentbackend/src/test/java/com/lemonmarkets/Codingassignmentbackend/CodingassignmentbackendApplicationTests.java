package com.lemonmarkets.Codingassignmentbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingassignmentbackendApplicationTests {

	@Test
	public void contextLoads() {
	}

}
