package com.lemonmarkets.Codingassignmentbackend;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lemonmarkets.Codingassignmentbackend.authentication.TestSecurityConfig;
import com.lemonmarkets.Codingassignmentbackend.controller.OrderReceiverController;
import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.Order;
import com.lemonmarkets.Codingassignmentbackend.model.OrderSide;
import com.lemonmarkets.Codingassignmentbackend.model.OrderType;
import com.lemonmarkets.Codingassignmentbackend.services.OrderService;
import com.lemonmarkets.Codingassignmentbackend.services.Validator;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * This class, CodingassignmentbackendApplicationTests, contains integration tests for the application endpoints.
 * It tests the functionality of creating and retrieving orders through the OrderReceiverController.
 */

@ExtendWith(SpringExtension.class)
@WebMvcTest(OrderReceiverController.class)
@AutoConfigureMockMvc
@ContextConfiguration(classes = TestSecurityConfig.class)
class CodingassignmentbackendApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private Validator validator;

	@MockBean
	private OrderService service;

	/**
	 * Tests the functionality of creating an order through the "/orders" endpoint.
	 *
	 * @throws Exception if an error occurs during the test
	 */
	@Test
	public void testCreateOrder() throws Exception {
		CreateOrderModel orderModel = createOrderModel();

		Order order = createOrder(orderModel);

		Mockito.when(validator.isValidOrder(Mockito.any())).thenReturn("");
		Mockito.when(service.createOrder(Mockito.any())).thenReturn(order);

		ResultActions result =mockMvc.perform(MockMvcRequestBuilders.post("/orders")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(orderModel)))
				.andExpect(MockMvcResultMatchers.status().isCreated())
				.andExpect(MockMvcResultMatchers.jsonPath("$.instrument").value(orderModel.getInstrument()));

		var response= deserializeBody( result.andReturn(),Order.class);
		Assertions.assertEquals(order.getInstrument(),response.getInstrument());
		Assertions.assertEquals(order.getLimitPrice(),response.getLimitPrice());
	}

	/**
	 * Tests the functionality of retrieving orders through the "/orders" endpoint.
	 *
	 * @throws Exception if an error occurs during the test
	 */
	@Test
	public void testGetOrders() throws Exception {
		List<Order> orders = new ArrayList<>();
		Order order= createOrder(createOrderModel());
		orders.add(order);

		Mockito.when(service.getOrders()).thenReturn(orders);

		ResultActions result =mockMvc.perform(MockMvcRequestBuilders.get("/orders"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.jsonPath("$").isArray());
		var response= deserializeBody( result.andReturn(),Order[].class);
		Assertions.assertEquals(order.getInstrument(),response[0].getInstrument());
		Assertions.assertEquals(order.getLimitPrice(),response[0].getLimitPrice());
	}

	/**
	 * Helper method to create an Order object.
	 *
	 * @param orderModel the CreateOrderModel object to create the Order from
	 * @return the created Order object
	 */
	private Order createOrder(CreateOrderModel orderModel)
	{
		Order order = new Order();
		order.setInstrument(orderModel.getInstrument());
		order.setQuantity(orderModel.getQuantity());
		order.setSide(orderModel.getSide());
		order.setType(orderModel.getType());
		order.setLimitPrice(orderModel.getLimitPrice());
		return order;
	}

	/**
	 * Helper method to create a CreateOrderModel object.
	 *
	 * @return the created CreateOrderModel object
	 */
	private CreateOrderModel createOrderModel()
	{
		CreateOrderModel orderModel = new CreateOrderModel();
		orderModel.setInstrument("Test Instrument");
		orderModel.setLimitPrice(new BigDecimal(100.0));
		orderModel.setQuantity(10);
		orderModel.setSide(OrderSide.BUY);
		orderModel.setType(OrderType.LIMIT);
		return orderModel;
	}

	/**
	 * Helper method to deserialize the response body into a specified type.
	 *
	 * @param mvcResult the MvcResult containing the response
	 * @param type      the Class type to deserialize the body into
	 * @return the deserialized object
	 * @throws IOException if an error occurs during deserialization
	 */
	private <T> T deserializeBody(
			MvcResult mvcResult, Class<T> type) throws IOException {
		var objectMapper = new ObjectMapper();
		objectMapper.registerModule(new JavaTimeModule());
		var body = mvcResult.getResponse().getContentAsString();
		return objectMapper.readValue(body, type);
	}

}
