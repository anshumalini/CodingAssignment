package com.lemonmarkets.Codingassignmentbackend.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import com.lemonmarkets.Codingassignmentbackend.model.OrderSide;
import com.lemonmarkets.Codingassignmentbackend.model.OrderType;
import com.lemonmarkets.Codingassignmentbackend.services.OrderExecutor;
import com.lemonmarkets.Codingassignmentbackend.services.OrderService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.Order;
import com.lemonmarkets.Codingassignmentbackend.repository.OrderRepo;

import static org.mockito.Mockito.*;

/**
 * This class, OrderServiceTest, contains unit tests for the OrderService class.
 * It tests the createOrder and getOrders methods.
 */
public class OrderServiceTest {

    @InjectMocks
    private OrderService orderService;
    @Mock
    private OrderRepo orderRepoMock;
    @Mock
    private OrderExecutor orderExecutorMock;

    /**
     * Initializes mocks before each test method.
     */
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Tests the createOrder method of OrderService.
     *
     * @throws Exception if an error occurs during order creation
     */
    @Test
    public void testCreateOrder() throws Exception {
        // Arrange
        CreateOrderModel model = new CreateOrderModel();
        model.setInstrument("Test Instrument");
        model.setLimitPrice(new BigDecimal(100.0));
        model.setQuantity(10);
        model.setSide(OrderSide.BUY);
        model.setType(OrderType.LIMIT);

        Order expectedOrder = new Order();
        expectedOrder.setCreatedAt(LocalDateTime.now());
        expectedOrder.setInstrument(model.getInstrument());
        expectedOrder.setLimitPrice(model.getLimitPrice());
        expectedOrder.setQuantity(model.getQuantity());
        expectedOrder.setSide(model.getSide());
        expectedOrder.setType(model.getType());

        ArgumentCaptor<Order> orderArgumentCaptor = ArgumentCaptor.forClass(Order.class);
        doNothing().when(orderExecutorMock).placeOrderWithTimeout(orderArgumentCaptor.capture(), Mockito.any(Long.class));
        when(orderRepoMock.save(Mockito.any(Order.class))).thenReturn(expectedOrder);


        // Act
        Order createdOrder = orderService.createOrder(model);

        // Assert
        Assertions.assertEquals(expectedOrder.getInstrument(), createdOrder.getInstrument());
        Assertions.assertEquals(expectedOrder.getSide(), createdOrder.getSide());
        Assertions.assertEquals(expectedOrder.getQuantity(), createdOrder.getQuantity());
        Assertions.assertEquals(expectedOrder.getLimitPrice(), createdOrder.getLimitPrice());


        verify(orderExecutorMock,atLeast(1)).placeOrderWithTimeout(orderArgumentCaptor.capture(), Mockito.any(Long.class));
        Assertions.assertEquals(expectedOrder.getInstrument(), orderArgumentCaptor.getValue().getInstrument());
        Assertions.assertEquals(expectedOrder.getLimitPrice(), orderArgumentCaptor.getValue().getLimitPrice());
    }

    /**
     * Tests the getOrders method of OrderService.
     */
    @Test
    public void testGetOrders() {
        // Arrange
        List<Order> expectedOrders = new ArrayList<>();
        when(orderRepoMock.getOrders()).thenReturn(expectedOrders);

        // Act
        List<Order> retrievedOrders = orderService.getOrders();

        // Assert
        Assertions.assertEquals(expectedOrders, retrievedOrders);
        verify(orderRepoMock).getOrders();
    }
}

