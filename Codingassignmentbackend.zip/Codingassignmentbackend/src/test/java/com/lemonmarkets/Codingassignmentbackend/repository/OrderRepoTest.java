package com.lemonmarkets.Codingassignmentbackend.repository;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


public class OrderRepoTest {

	@InjectMocks
	private OrderRepo orderRepo;
	
	@Mock
    private OrderReposirtory orderRepository;

    @BeforeEach
    void setUp() {
    	        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveOrder() {
        Order order = new Order();
        order.setInstrument("XYZ");
        order.setQuantity(100);
        order.setSide(OrderSide.BUY);
        order.setType(OrderType.LIMIT);
        order.setLimitPrice(Optional.of(new BigDecimal(50.0)));

        // Mock behavior for OrderRepository save method
        when(orderRepository.save(Mockito.any(OrderDto.class))).thenReturn(new OrderDto());

        // Perform save operation
        orderRepo.save(order);

        // Verify that OrderDto is created and saved with the correct values
        // Add verification code here based on your specific requirements
    }

   /* @Test
    void testGetOrders() {
        // Prepare mock data for OrderDto
        OrderDto orderDto1 = new OrderDto();
        orderDto1.setCreatedAt(LocalDateTime.now());
        orderDto1.setInstrument("ABC");
        orderDto1.setQuantity(200);
        orderDto1.setSide("SELL");
        orderDto1.setType(OrderType.MARKET);

        OrderDto orderDto2 = new OrderDto();
        orderDto2.setCreatedAt(LocalDateTime.now());
        orderDto2.setInstrument("XYZ");
        orderDto2.setQuantity(100);
        orderDto2.setSide("BUY");
        orderDto2.setType(OrderType.LIMIT);
        orderDto2.setLimitPrice(50.0);

        List<OrderDto> orderDtoList = new ArrayList<>();
        orderDtoList.add(orderDto1);
        orderDtoList.add(orderDto2);

        // Mock behavior for OrderRepository findAll method
        when(orderRepository.findAll()).thenReturn(orderDtoList);

        // Perform getOrders operation
        List<Order> orders = orderRepo.getOrders();

        // Verify that the returned list of orders matches the expected size
        assertEquals(2, orders.size());

        // Add additional verification code here based on your specific requirements
    }*/
}
