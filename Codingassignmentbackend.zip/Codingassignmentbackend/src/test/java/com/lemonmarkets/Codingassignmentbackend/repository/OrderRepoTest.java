package com.lemonmarkets.Codingassignmentbackend.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.lemonmarkets.Codingassignmentbackend.model.Order;
import com.lemonmarkets.Codingassignmentbackend.model.OrderSide;
import com.lemonmarkets.Codingassignmentbackend.model.OrderType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;

/**
 * This class, OrderRepoTest, contains unit tests for the OrderRepo class.
 * It tests the save and retrieval operations of orders.
 */

public class OrderRepoTest {

	@InjectMocks
	private OrderRepo orderRepo;
	
	@Mock
    private OrderReposirtory orderRepository;

    /**
     * Initializes mocks before each test method.
     */
    @BeforeEach
    void setUp() {
    	        MockitoAnnotations.openMocks(this);
    }

    /**
     * Tests the save operation for an order.
     */
    @Test
    void testSaveOrder() {
        Order order = new Order();
        order.setInstrument("XYZ");
        order.setQuantity(100);
        order.setSide(OrderSide.BUY);
        order.setType(OrderType.LIMIT);
        order.setLimitPrice(new BigDecimal(50.0));

        OrderDto expectedDto = new OrderDto();
        expectedDto.setId(1L);
        expectedDto.setCreatedAt(LocalDateTime.now());
        expectedDto.setInstrument(order.getInstrument());
        expectedDto.setLimitPrice(order.getLimitPrice().get());
        expectedDto.setQuantity(order.getQuantity());
        expectedDto.setSide(order.getSide());
        expectedDto.setType(order.getType());
        when(orderRepository.save(Mockito.any(OrderDto.class))).thenReturn(expectedDto);

        //  save operation
        orderRepo.save(order);

        verify(orderRepository,times(1)).save(Mockito.any(OrderDto.class));

    }

    /**
     * Tests the retrieval of orders.
     */
    @Test
    void testGetOrders() {
        //  mocking data for OrderDto
        OrderDto orderDto1 = new OrderDto();
        orderDto1.setCreatedAt(LocalDateTime.now());
        orderDto1.setInstrument("ABC");
        orderDto1.setId(1L);
        orderDto1.setQuantity(200);
        orderDto1.setSide(OrderSide.SELL);
        orderDto1.setType(OrderType.MARKET);

        OrderDto orderDto2 = new OrderDto();
        orderDto2.setId(2L);
        orderDto2.setCreatedAt(LocalDateTime.now());
        orderDto2.setInstrument("XYZ");
        orderDto2.setQuantity(100);
        orderDto2.setSide(OrderSide.BUY);
        orderDto2.setType(OrderType.LIMIT);
        orderDto2.setLimitPrice(new BigDecimal(50.0));

        List<OrderDto> orderDtoList = new ArrayList<>();
        orderDtoList.add(orderDto1);
        orderDtoList.add(orderDto2);

        // Mocking behavior for OrderRepository findAll method
        when(orderRepository.findAll()).thenReturn(orderDtoList);

        // Perform getOrders operation
        List<Order> orders = orderRepo.getOrders();

        // Verify that the returned list of orders matches the expected size
        Assertions.assertEquals(2, orders.size());

    }
}
