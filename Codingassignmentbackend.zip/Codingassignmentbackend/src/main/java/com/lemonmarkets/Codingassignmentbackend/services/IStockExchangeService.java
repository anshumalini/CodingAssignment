package com.lemonmarkets.Codingassignmentbackend.services;

import com.lemonmarkets.Codingassignmentbackend.exception.OrderPlacementError;
import com.lemonmarkets.Codingassignmentbackend.model.Order;

public interface IStockExchangeService {

    public void placeOrder(Order order) throws OrderPlacementError;

}

