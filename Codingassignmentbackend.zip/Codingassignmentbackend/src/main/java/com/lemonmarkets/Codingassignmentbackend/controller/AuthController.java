package com.lemonmarkets.Codingassignmentbackend.controller;

import com.lemonmarkets.Codingassignmentbackend.authentication.LoginRequest;
import com.lemonmarkets.Codingassignmentbackend.authentication.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller class responsible for handling authentication-related HTTP requests.
 */
@RestController
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;


    @Autowired
    private JwtTokenProvider tokenProvider;

    @Autowired
    private UserDetailsService userDetailsService;

    /**
     * Handles HTTP POST requests to authenticate a user.
     *
     * @param loginRequest the login request containing the user's credentials
     * @return the JWT token if authentication is successful, otherwise an error message
     */

    @PostMapping("/login")
    public String authenticateUser(@RequestBody LoginRequest loginRequest) {
        // Check if the provided credentials match those stored in the database
        if (!userDetailsService.loadUserByUsername(loginRequest.getUsername()).getPassword().equals(loginRequest.getPassword())) {
            return "Invalid credentials";
        }

        // Authenticate the user using the provided credentials
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );

        // Set the authentication object in the security context holder
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Generate and return a JWT token
        return tokenProvider.generateToken(loginRequest.getUsername());
    }
}

