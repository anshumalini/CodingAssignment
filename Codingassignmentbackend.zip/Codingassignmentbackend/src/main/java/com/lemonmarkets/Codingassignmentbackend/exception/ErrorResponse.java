package com.lemonmarkets.Codingassignmentbackend.exception;

/**
 * Represents an error response with a message.
 */
public class ErrorResponse {

	private String message;

    /**
     * Constructs an ErrorResponse object with the provided message.
     * @param message The error message.
     */
    public ErrorResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    
}
