package com.lemonmarkets.Codingassignmentbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This class, CodingassignmentbackendApplication, serves as the entry point for the Spring Boot application.
 * It is annotated with @SpringBootApplication, which indicates that it is a Spring Boot application.
 * The main() method starts the Spring Boot application by calling SpringApplication.run().
 */
@SpringBootApplication
public class CodingassignmentbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingassignmentbackendApplication.class, args);
	}

}
