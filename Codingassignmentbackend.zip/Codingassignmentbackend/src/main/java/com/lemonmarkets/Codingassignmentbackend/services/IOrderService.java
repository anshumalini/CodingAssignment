package com.lemonmarkets.Codingassignmentbackend.services;

import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.Order;

import java.util.List;

public interface IOrderService {

    public Order createOrder(CreateOrderModel model);

    public List<Order> getOrders();
}
