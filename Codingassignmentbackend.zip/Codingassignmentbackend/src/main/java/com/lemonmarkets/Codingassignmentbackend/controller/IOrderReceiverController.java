package com.lemonmarkets.Codingassignmentbackend.controller;

import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;

public interface IOrderReceiverController {

    public ResponseEntity<?> createOrder(@Validated @RequestBody CreateOrderModel model);

    public ResponseEntity<?> getOrders();
}
