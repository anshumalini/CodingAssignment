package com.lemonmarkets.Codingassignmentbackend.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.lemonmarkets.Codingassignmentbackend.model.OrderSide;
import com.lemonmarkets.Codingassignmentbackend.model.OrderType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * This class represents the Order entity in the database, mapped to the "orders" table.
 * It contains fields corresponding to the attributes of an order such as ID, creation timestamp, type, side, instrument,
 * limit price, and quantity.
 */
@Entity
@Table(name = "orders")
public class OrderDto {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    private OrderType type;

    @Enumerated(EnumType.STRING)
    @Column(name = "side", nullable = false)
    private OrderSide side;

    @Column(name = "instrument", nullable = false)
    private String instrument;

    @Column(name = "limit_price")
    private BigDecimal limitPrice;

    @Column(name = "quantity", nullable = false)
    private int quantity;

    // Default constructor
    public OrderDto() {
    }

    // Parameterized constructor
    public OrderDto(LocalDateTime createdAt, OrderType type, OrderSide side, String instrument, BigDecimal limitPrice, int quantity) {
        this.createdAt = createdAt;
        this.type = type;
        this.side = side;
        this.instrument = instrument;
        this.limitPrice = limitPrice;
        this.quantity = quantity;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public OrderType getType() {
        return type;
    }

    public void setType(OrderType type) {
        this.type = type;
    }

    public OrderSide getSide() {
        return side;
    }

    public void setSide(OrderSide side) {
        this.side = side;
    }

    public String getInstrument() {
        return instrument;
    }

    public void setInstrument(String instrument) {
        this.instrument = instrument;
    }

    public BigDecimal getLimitPrice() {
        return limitPrice;
    }

    public void setLimitPrice(BigDecimal limitPrice) {
        this.limitPrice = limitPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

}
