package com.lemonmarkets.Codingassignmentbackend.model;

public enum OrderSide {
	BUY, SELL
}
