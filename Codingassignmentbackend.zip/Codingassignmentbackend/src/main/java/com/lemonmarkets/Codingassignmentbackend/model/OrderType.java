package com.lemonmarkets.Codingassignmentbackend.model;

public enum OrderType {
	MARKET, LIMIT
}
