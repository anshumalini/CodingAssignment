package com.lemonmarkets.Codingassignmentbackend.services;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.stereotype.Component;

/**
 * This class, PropertyReader, provides utility methods for reading properties from an external properties file.
 * It loads properties from the "application.properties" file located in the "src/main/resources" directory.
 * The getProperty() method retrieves the value of a specified property by its name.
 */
@Component
public class PropertyReader {

    /**
     * Retrieves the value of a property by its name from the "application.properties" file.
     *
     * @param name The name of the property to retrieve.
     * @return The value of the property, or null if the property is not found or an error occurs.
     */
	public  static String getProperty(String name)
	{
		Properties properties = new Properties();
		String property = null;
        try (InputStream input = new FileInputStream("src/main/resources/application.properties")) {
            properties.load(input);
           // Read properties
            property = properties.getProperty(name);
         
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        return property;
	}
}
