package com.lemonmarkets.Codingassignmentbackend.services;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.stereotype.Component;

@Component
public class PropertyReader {

	public  static String getProperty(String name)
	{
		Properties properties = new Properties();
		String property = null;
        try (InputStream input = new FileInputStream("src/main/resources/application.properties")) {
            properties.load(input);
           // Read properties
            property = properties.getProperty(name);
         
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        return property;
	}
}
