package com.lemonmarkets.Codingassignmentbackend.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Represents an order in the Lemon Markets system.
 */
public class Order {

	// Fields and methods

	private long id;
	private LocalDateTime createdAt;
	private OrderType type;
	private OrderSide side;
	private String instrument;
	private BigDecimal limitPrice;
	private int quantity;

	public Order() {
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public OrderType getType() {
		return type;
	}

	public void setType(OrderType type) {
		this.type = type;
	}

	public OrderSide getSide() {
		return side;
	}

	public void setSide(OrderSide side) {
		this.side = side;
	}

	public String getInstrument() {
		return instrument;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}

	public Optional<BigDecimal> getLimitPrice() {
		return Optional.ofNullable(limitPrice);
	}

	public void setLimitPrice(BigDecimal limitPrice) {
		if (limitPrice != null) {
			this.limitPrice = limitPrice.setScale(2, BigDecimal.ROUND_HALF_UP);
		} else {
			this.limitPrice = null;
		}
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
