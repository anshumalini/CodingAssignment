package com.lemonmarkets.Codingassignmentbackend.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

public class Order {

	private LocalDateTime createdAt;
	private OrderType type;
	private OrderSide side;
	private String instrument;
	private Optional<BigDecimal> limitPrice;
	private int quantity;

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public OrderType getType() {
		return type;
	}

	public void setType(OrderType type) {
		this.type = type;
	}

	public OrderSide getSide() {
		return side;
	}

	public void setSide(OrderSide side) {
		this.side = side;
	}

	public String getInstrument() {
		return instrument;
	}

	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}

	public Optional<BigDecimal> getLimitPrice() {
		return limitPrice;
	}

	public void setLimitPrice(Optional<BigDecimal> limitPrice) {
		this.limitPrice = limitPrice!=null?
				limitPrice.map(price -> price.setScale(2, BigDecimal.ROUND_HALF_UP)):null;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
