package com.lemonmarkets.Codingassignmentbackend.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lemonmarkets.Codingassignmentbackend.model.Order;
import com.lemonmarkets.Codingassignmentbackend.model.OrderType;

@Repository
public class OrderRepo {

	
	private final OrderReposirtory reposirtory;
	
	@Autowired
	public OrderRepo( OrderReposirtory orderReposirtory) {
		reposirtory=orderReposirtory;
	}
	
	
	@Transactional
	public void save(Order order)
	{
		OrderDto dto= new OrderDto();
		dto.setCreatedAt(LocalDateTime.now());
		dto.setInstrument(order.getInstrument());
		if(OrderType.LIMIT.equals(order.getType()))
		{
			dto.setLimitPrice(order.getLimitPrice().get());
		}
		dto.setQuantity(order.getQuantity());
		dto.setSide(order.getSide());
		dto.setType(order.getType());
		reposirtory.save(dto);
	}
	
	public List<Order> getOrders()
	{
		List<OrderDto> dtos=reposirtory.findAll();
		return dtos.stream()
                .map(this::transformDtoOrder)
                .collect(Collectors.toList());
		
	}
	
	public Order transformDtoOrder(OrderDto orderDto)
	{
		Order order= new Order();
		order.setCreatedAt(orderDto.getCreatedAt());
		order.setInstrument(orderDto.getInstrument());
		order.setType(orderDto.getType());
		if(OrderType.LIMIT.equals(orderDto.getType()))
		{
			order.setLimitPrice(Optional.of(orderDto.getLimitPrice()));
		}	
		order.setQuantity(orderDto.getQuantity());
		order.setSide(orderDto.getSide());
		return order;
	}
	
	
}
