package com.lemonmarkets.Codingassignmentbackend.services;

import java.util.concurrent.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lemonmarkets.Codingassignmentbackend.model.Order;

@Component
public class OrderExecutor {

	private static final ExecutorService executor = Executors.newSingleThreadExecutor();
	private static final long DEFAULT_TIMEOUT_SECONDS = 60; // Default timeout in seconds
	@Autowired
	private StockExchangeService exchangeService;

	public void placeOrderWithTimeout(Order order, long timeoutSeconds) throws Exception {
		CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
			try {
				exchangeService.placeOrder(order); // Assuming exchangeService is an instance variable
			} catch (Exception e) {
				throw new CompletionException(e);
			}
		}, executor);

		try {
			future.get(timeoutSeconds, TimeUnit.SECONDS); // Wait for the task to complete within the specified timeout
		} catch (TimeoutException e) {
			// If the task didn't complete within the timeout, cancel it
			future.cancel(true);
			throw new Exception("Timeout occurred while placing order");
		} catch (InterruptedException e) {
			// Handle interruption
			throw new Exception("Task interrupted while placing order");
		} catch (ExecutionException e) {
			// Handle execution exception - retry if necessary
			handleExecutionException(e.getCause(),order);
		}
	}

	// Retry logic in case of execution exception
	private void handleExecutionException(Throwable cause , Order order) throws Exception {
        if (cause instanceof TimeoutException ) {
            // Handle the specific exception - decide whether to retry or not
            if (shouldRetry()) {
                // Retry the method call
                placeOrderWithTimeout(order, DEFAULT_TIMEOUT_SECONDS);
            } else {
                throw new Exception("Error occurred while placing order: " + cause.getMessage());
            }
        } else {
            // For other types of exceptions, just propagate them
            throw new Exception("Error occurred while placing order: " + cause.getMessage());
        }
    }

	private boolean shouldRetry() {
		// Implement your retry condition logic here
		return true; // For example, always retry in this case
	}

	// Shutdown the executor when the application exits
	public void shutdown() {
		executor.shutdown();
	}
}
