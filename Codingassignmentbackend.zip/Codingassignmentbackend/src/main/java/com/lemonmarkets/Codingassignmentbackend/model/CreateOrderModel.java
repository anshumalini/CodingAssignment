package com.lemonmarkets.Codingassignmentbackend.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CreateOrderModel {

	@JsonProperty("type")
	private OrderType type;

	@JsonProperty("side")
    private OrderSide side;

	@JsonProperty("instrument")
    private String instrument;

	@JsonProperty("limitPrice")
    private BigDecimal limitPrice;

	@JsonProperty("quantity")
    private int quantity;

	public OrderType getType() {
		return type;
	}

	public void setType(OrderType type) {
		this.type = type;
	}

	public OrderSide getSide() {
		return side;
	}

	public void setSide(OrderSide side) {
		this.side = side;
	}

	public String getInstrument() {
		return instrument;
	}

	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}

	public BigDecimal getLimitPrice() {
		return limitPrice;
	}

	public void setLimitPrice(BigDecimal limitPrice) {
		this.limitPrice = limitPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
    
    
}
