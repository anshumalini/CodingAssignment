package com.lemonmarkets.Codingassignmentbackend.repository;


import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderReposirtory extends JpaRepository<OrderDto, Long>{
	

}
