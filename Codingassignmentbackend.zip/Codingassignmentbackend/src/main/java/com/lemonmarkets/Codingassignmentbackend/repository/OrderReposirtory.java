package com.lemonmarkets.Codingassignmentbackend.repository;


import org.springframework.data.jpa.repository.JpaRepository;

/**
 * This interface extends JpaRepository to provide basic CRUD operations for the OrderDto entity.
 * It allows the application to interact with the database and perform operations such as saving, updating,
 * deleting, and querying OrderDto objects.
 */
public interface OrderReposirtory extends JpaRepository<OrderDto, Long>{
	

}
