package com.lemonmarkets.Codingassignmentbackend.exception;

/**
 * Represents an exception thrown when there is an error in order placement.
 */
public class OrderPlacementError extends Exception {
	   
	private static final long serialVersionUID = 1537458236433889808L;

	/**
	 * Constructs an OrderPlacementError object with the provided message.
	 * @param message The error message.
	 */
	public OrderPlacementError(String message) {
	        super(message);
	    }
}
