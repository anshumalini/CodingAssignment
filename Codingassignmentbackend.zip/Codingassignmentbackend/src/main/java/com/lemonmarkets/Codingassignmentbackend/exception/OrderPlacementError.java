package com.lemonmarkets.Codingassignmentbackend.exception;

public class OrderPlacementError extends Exception {
	   
	private static final long serialVersionUID = 1537458236433889808L;

		public OrderPlacementError(String message) {
	        super(message);
	    }
}
