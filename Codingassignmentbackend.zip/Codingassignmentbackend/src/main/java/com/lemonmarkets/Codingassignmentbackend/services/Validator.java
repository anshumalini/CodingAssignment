package com.lemonmarkets.Codingassignmentbackend.services;

import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.OrderType;

/**
 * This component class, Validator, provides methods to validate orders before they are processed.
 * It includes validation rules based on the order type and instrument length.
 */
@Component
public class Validator {

	/**
	 * Validates the provided order model.
	 *
	 * @param model The order model to be validated.
	 * @return A validation message indicating any issues found during validation.
	 */
	public String isValidOrder(CreateOrderModel model)
	{
		if(OrderType.MARKET.equals(model.getType()) && !ObjectUtils.isEmpty(model.getLimitPrice()))
		{
			return "Providing a `limit_price` is prohibited for type `market`";
		}
		else if(OrderType.LIMIT.equals(model.getType()) && ObjectUtils.isEmpty(model.getLimitPrice()))
		{
			return "Attribute `limit_price` is required for type `limit`";
		}
		
		if(model.getInstrument().length()!=12)
		{
			return "Instrument with invalid length ";
		}
		
		return "";  // Indicates the order is valid
	}
	
}
