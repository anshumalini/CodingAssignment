package com.lemonmarkets.Codingassignmentbackend.services;

import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.OrderType;

@Component
public class Validator {
	
	public String isValidOrder(CreateOrderModel model)
	{
		if(OrderType.MARKET.equals(model.getType()) && !ObjectUtils.isEmpty(model.getLimitPrice()))
		{
			return "Providing a `limit_price` is prohibited for type `market`";
		}
		else if(OrderType.LIMIT.equals(model.getType()) && ObjectUtils.isEmpty(model.getLimitPrice()))
		{
			return "Attribute `limit_price` is required for type `limit`";
		}
		
		if(model.getInstrument().length()!=12)
		{
			return "Instrument with invalid length ";
		}
		
		return "";
	}
	
}
