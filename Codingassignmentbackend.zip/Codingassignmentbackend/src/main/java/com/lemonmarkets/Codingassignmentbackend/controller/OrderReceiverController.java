package com.lemonmarkets.Codingassignmentbackend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lemonmarkets.Codingassignmentbackend.exception.ErrorResponse;
import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.Order;
import com.lemonmarkets.Codingassignmentbackend.services.OrderService;
import com.lemonmarkets.Codingassignmentbackend.services.Validator;

@RestController
public class OrderReceiverController {

	@Autowired
	private Validator validator;
	@Autowired
	private OrderService service;

	@PostMapping("/orders")
	public ResponseEntity<?> createOrder(@Validated @RequestBody CreateOrderModel model) {

		String validationMsg = validator.isValidOrder(model);
		if (!validationMsg.isEmpty()) {
			ErrorResponse response = new ErrorResponse(validationMsg);
			return ResponseEntity.badRequest().body(response);
		}
		Order order = service.createOrder(model);
		if (!ObjectUtils.isEmpty(order)) {
			return ResponseEntity.status(HttpStatus.CREATED).body(order);
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Internal server error while placing the order");
		}

	}

	@GetMapping("/orders")
	public ResponseEntity<?> getOrders() {

		List<Order> order = service.getOrders();
		if (!ObjectUtils.isEmpty(order)) {
			return ResponseEntity.status(HttpStatus.OK).body(order);
		} else {
			return ResponseEntity.status(HttpStatus.OK).body("No order found in DB");
		}

	}

}
