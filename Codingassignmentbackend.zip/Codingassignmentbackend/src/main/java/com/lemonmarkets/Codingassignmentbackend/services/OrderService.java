package com.lemonmarkets.Codingassignmentbackend.services;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lemonmarkets.Codingassignmentbackend.exception.OrderPlacementError;
import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.Order;
import com.lemonmarkets.Codingassignmentbackend.repository.OrderRepo;

/**
 * Service class responsible for order management operations.
 */
@Service
public class OrderService implements IOrderService{

	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private IOrderExecutor executor;

    private final static String DEFAULT_TIMEOUT="1000";

	/**
	 * Creates an order based on the provided model.
	 * @param model The model containing order details.
	 * @return The created order or null if an error occurs.
	 */
	public Order createOrder(CreateOrderModel model) {

        Order saveOrder;
        try {
			Order order = new Order();
            order.setCreatedAt(LocalDateTime.now());
            order.setInstrument(model.getInstrument());
            Optional.ofNullable(model.getLimitPrice())
                    .ifPresentOrElse(
                            limit -> order.setLimitPrice(model.getLimitPrice()),
                            () -> order.setLimitPrice(null)
                    );

            order.setQuantity(model.getQuantity());
            order.setSide(model.getSide());
            order.setType(model.getType());
            saveOrder = orderRepo.save(order);

            // Retrieving the stock exchange timeout value from the properties file. If the property is not found,
             // if it is null, the DEFAULT_TIMEOUT value is used instead.
            String timeout = PropertyReader.getProperty("stockExchangeTimeoutInMs")!=null
                    ?PropertyReader.getProperty("stockExchangeTimeoutInMs"):DEFAULT_TIMEOUT;

            executor.placeOrderWithTimeout(saveOrder, Long.parseLong(timeout));

        } catch (OrderPlacementError e) {
            e.printStackTrace();
            return null;
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return saveOrder;
    }


	/**
	 * Retrieves all orders.
	 * @return A list of orders.
	 */
	public List<Order> getOrders()
	{
		return orderRepo.getOrders();
	}
}
