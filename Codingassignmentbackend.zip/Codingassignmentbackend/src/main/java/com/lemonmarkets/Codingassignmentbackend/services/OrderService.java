package com.lemonmarkets.Codingassignmentbackend.services;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lemonmarkets.Codingassignmentbackend.exception.OrderPlacementError;
import com.lemonmarkets.Codingassignmentbackend.model.CreateOrderModel;
import com.lemonmarkets.Codingassignmentbackend.model.Order;
import com.lemonmarkets.Codingassignmentbackend.repository.OrderRepo;

@Service
public class OrderService {

	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private OrderExecutor executor;
	
	public Order createOrder(CreateOrderModel model)
	{	
		Order order= new Order();; 
		try {
		order.setCreatedAt(LocalDateTime.now());
		order.setInstrument(model.getInstrument());
		Optional.ofNullable(model.getLimitPrice())
	    .ifPresentOrElse(
	        limit -> order.setLimitPrice(Optional.ofNullable(model.getLimitPrice())),
	        () -> order.setLimitPrice(null)
	    );

		order.setQuantity(model.getQuantity());
		order.setSide(model.getSide());
		order.setType(model.getType());
		orderRepo.save(order);
		
		String timeout=PropertyReader.getProperty("stockExchangeTimeoutInMs");
		executor.placeOrderWithTimeout(order,Long.valueOf(timeout));
		
		} catch (OrderPlacementError e) {
			e.printStackTrace();
			return null;
		} catch (NumberFormatException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {	
			e.printStackTrace();
			return null;
		}
		
		return order;
	}
	
	public List<Order> getOrders()
	{
		return orderRepo.getOrders();
	}
}
