package com.lemonmarkets.Codingassignmentbackend.services;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import com.lemonmarkets.Codingassignmentbackend.exception.OrderPlacementError;
import com.lemonmarkets.Codingassignmentbackend.model.Order;

/**
 * This service class, StockExchangeService, simulates the process of placing an order at the stock exchange.
 * It provides a method, placeOrder(), which accepts an Order object and simulates the order placement process.
 * The method includes logic to handle various scenarios such as null order, connection failure, and a simulated
 * delay to mimic the time-consuming nature of the operation.
 */
@Service
public class StockExchangeService implements IStockExchangeService{

    /**
     * Simulates the process of placing an order at the stock exchange.
     *
     * @param order The order to be placed.
     * @throws OrderPlacementError if the order placement fails due to various reasons.
     */
	public void placeOrder(Order order) throws OrderPlacementError {
        // Dummy function symbolic of placing an order at the stock exchange
        if (order == null) {
            throw new IllegalArgumentException("Required order parameter not provided");
        }

        Random random = new Random();
        if (random.nextDouble() >= 0.9) {
            throw new OrderPlacementError("Failed to place order at stock exchange. Connection not available");
        }

        // Simulate an expensive operation
        try {
            TimeUnit.MILLISECONDS.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
