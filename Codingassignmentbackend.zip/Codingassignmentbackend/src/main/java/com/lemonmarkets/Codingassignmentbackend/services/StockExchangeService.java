package com.lemonmarkets.Codingassignmentbackend.services;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import com.lemonmarkets.Codingassignmentbackend.exception.OrderPlacementError;
import com.lemonmarkets.Codingassignmentbackend.model.Order;

@Service
public class StockExchangeService {

	public void placeOrder(Order order) throws OrderPlacementError {
        // Dummy function symbolic of placing an order at the stock exchange
        if (order == null) {
            throw new IllegalArgumentException("Required order parameter not provided");
        }

        Random random = new Random();
        if (random.nextDouble() >= 0.9) {
            throw new OrderPlacementError("Failed to place order at stock exchange. Connection not available");
        }

        // Simulate an expensive operation
        try {
            TimeUnit.MILLISECONDS.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
