package com.lemonmarkets.Codingassignmentbackend.services;

import com.lemonmarkets.Codingassignmentbackend.model.Order;

public interface IOrderExecutor {

    public void placeOrderWithTimeout(Order order, long timeoutSeconds) throws Exception;

    public void shutdown();
}
